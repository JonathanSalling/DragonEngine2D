#pragma once
#include "Vector.h"

struct SDL_Renderer;
struct SDL_Window;
struct MIX_Mixer;

namespace DragonEngine
{
	class Engine
	{
	public:
		Engine();
		~Engine();
		int Start();
		void Shutdown();

		void StartRender();
		void RenderPresent();

		static Engine& GetInstance()
		{
			static Engine instance;
			return instance;
		}

		SDL_Renderer* GetRenderer() const { return myRenderer; }
		SDL_Window* GetWindow() const { return myWindow; }
		MIX_Mixer* GetMixer() const { return myMixer; }

		unsigned short GetWindowWidth() const { return myWindowWidth; }
		unsigned short GetWindowHeight() const { return myWindowHeight; }

		unsigned short GetRenderWidth() const { return myRenderWidth; }
		unsigned short GetRenderHeight() const { return myRenderHeight; }
		Vector2<unsigned int> GetRenderResolution() const { return { myRenderWidth, myRenderHeight }; }

		Vector2f NormalSpaceToScreenSpace(Vector2f const& aNormalizedVector) const
		{
			return { aNormalizedVector.x * myRenderWidth, aNormalizedVector.y * myRenderHeight };
		}

	private:
		/* We will use this renderer to draw into this window every frame. */
		SDL_Renderer* myRenderer = NULL;
		SDL_Window* myWindow = NULL;
		MIX_Mixer* myMixer = NULL;


		/* How big should the window be? */
		unsigned short myWindowWidth;
		unsigned short myWindowHeight;

		/* What resolution should we render everything in?*/
		unsigned short myRenderWidth;
		unsigned short myRenderHeight;
	};
}


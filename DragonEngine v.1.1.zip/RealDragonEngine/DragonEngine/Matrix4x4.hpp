#pragma once
#include <array>
#include <math.h>
#include <assert.h>
#include "Vector.h"

namespace DragonEngine
{
	template<class T>
	class Matrix4x4
	{
	public:
		// Creates the identity matrix.
		Matrix4x4<T>();
		// Copy Constructor.
		Matrix4x4<T>(const Matrix4x4<T>& aMatrix);
		// () operator for accessing element (row, column) for read/write or read, respectively.
		T& operator()(const int aRow, const int aColumn);
		const T& operator()(const int aRow, const int aColumn) const;

		Matrix4x4<T> operator+(const Matrix4x4<T>& aMatrix);
		Matrix4x4<T>& operator+=(const Matrix4x4<T>& aMatrix);
		Matrix4x4<T> operator-(const Matrix4x4<T>& aMatrix);
		Matrix4x4<T>& operator-=(const Matrix4x4<T>& aMatrix);
		Matrix4x4<T> operator*(const Matrix4x4<T>& aMatrix);
		Matrix4x4<T>& operator*=(const Matrix4x4<T>& aMatrix);

		Matrix4x4<T>& operator=(const Matrix4x4<T>& aMatrix);
		bool operator==(const Matrix4x4<T>& aMatrix0) const;
		// Static functions for creating rotation matrices.a
		static Matrix4x4<T> CreateRotationAroundX(T aAngleInRadians);
		static Matrix4x4<T> CreateRotationAroundY(T aAngleInRadians);
		static Matrix4x4<T> CreateRotationAroundZ(T aAngleInRadians);
		// Static function for creating a transpose of a matrix.
		static Matrix4x4<T> Transpose(const Matrix4x4<T>& aMatrixToTranspose);

	private:
		std::array<std::array<T, 4>, 4> myMatrix;
	};
	template<class T>
	inline Matrix4x4<T>::Matrix4x4()
	{
		myMatrix[0][0] = 1;
		myMatrix[0][1] = 0;
		myMatrix[0][2] = 0;
		myMatrix[0][3] = 0;

		myMatrix[1][0] = 0;
		myMatrix[1][1] = 1;
		myMatrix[1][2] = 0;
		myMatrix[1][3] = 0;

		myMatrix[2][0] = 0;
		myMatrix[2][1] = 0;
		myMatrix[2][2] = 1;
		myMatrix[2][3] = 0;

		myMatrix[3][0] = 0;
		myMatrix[3][1] = 0;
		myMatrix[3][2] = 0;
		myMatrix[3][3] = 1;
	}
	template<class T>
	inline Matrix4x4<T>::Matrix4x4(const Matrix4x4<T>& aMatrix)
	{
		myMatrix = aMatrix.myMatrix;
	}

	template<class T>
	inline T& Matrix4x4<T>::operator()(const int aRow, const int aColumn)
	{
		assert(aRow >= 1 && aRow < 4 + 1);
		assert(aColumn >= 1 && aColumn < 4 + 1);
		return myMatrix[aRow - 1][aColumn - 1];
	}

	template<class T>
	inline const T& Matrix4x4<T>::operator()(const int aRow, const int aColumn) const
	{
		assert(aRow >= 1 && aRow < 4 + 1);
		assert(aColumn >= 1 && aColumn < 4 + 1);
		return myMatrix[aRow - 1][aColumn - 1];
	}

	template<class T>
	inline Matrix4x4<T> Matrix4x4<T>::operator+(const Matrix4x4<T>& aMatrix)
	{
		Matrix4x4<T> temp;
		for (unsigned int rows = 0; rows < 4; rows++)
		{
			for (unsigned int columns = 0; columns < 4; columns++)
			{
				temp.myMatrix[rows][columns] = myMatrix[rows][columns] + aMatrix(rows + 1, columns + 1);
			}
		}
		return temp;
	}

	template<class T>
	inline Matrix4x4<T>& Matrix4x4<T>::operator+=(const Matrix4x4<T>& aMatrix)
	{
		return (*this) = (*this) + aMatrix;
	}

	template<class T>
	inline Matrix4x4<T> Matrix4x4<T>::operator-(const Matrix4x4<T>& aMatrix)
	{
		Matrix4x4<T> temp;
		for (unsigned int rows = 0; rows < 4; rows++)
		{
			for (unsigned int columns = 0; columns < 4; columns++)
			{
				temp.myMatrix[rows][columns] = myMatrix[rows][columns] - aMatrix(rows + 1, columns + 1);
			}
		}
		return temp;
	}

	template<class T>
	inline Matrix4x4<T>& Matrix4x4<T>::operator-=(const Matrix4x4<T>& aMatrix)
	{
		return (*this) = (*this) - aMatrix;
	}

	template<class T>
	inline Matrix4x4<T> Matrix4x4<T>::operator*(const Matrix4x4<T>& aMatrix)
	{
		Matrix4x4<T> temp;
		for (unsigned int rows = 0; rows < 4; rows++)
		{
			for (unsigned int colums = 0; colums < 4; colums++)
			{
				T result = 0;
				for (unsigned int i = 0; i < 4; i++)
				{
					result += myMatrix[rows][i] * aMatrix(i + 1, colums + 1);
				}
				temp.myMatrix[rows][colums] = result;
			}
		}
		return temp;
	}

	template<class T>
	inline Matrix4x4<T>& Matrix4x4<T>::operator*=(const Matrix4x4<T>& aMatrix)
	{
		return (*this) = (*this) * aMatrix;
	}

	template<class T>
	inline Vector4<T> operator*(const Vector4<T>& aVector, const Matrix4x4<T>& aMatrix)
	{
		Vector4<T> temp;
		temp.x = aVector.x * aMatrix(1, 1) + aVector.y * aMatrix(2, 1) + aVector.z * aMatrix(3, 1) + aVector.w * aMatrix(4, 1);
		temp.y = aVector.x * aMatrix(1, 2) + aVector.y * aMatrix(2, 2) + aVector.z * aMatrix(3, 2) + aVector.w * aMatrix(4, 2);
		temp.z = aVector.x * aMatrix(1, 3) + aVector.y * aMatrix(2, 3) + aVector.z * aMatrix(3, 3) + aVector.w * aMatrix(4, 3);
		temp.w = aVector.x * aMatrix(1, 4) + aVector.y * aMatrix(2, 4) + aVector.z * aMatrix(3, 4) + aVector.w * aMatrix(4, 4);
		return temp;
	}

	template<class T>
	inline Vector4<T> operator*=(const Vector4<T>& aVector, const Matrix4x4<T>& aMatrix)
	{
		return (aMatrix * aVector);
	}

	template<class T>
	inline Matrix4x4<T>& Matrix4x4<T>::operator=(const Matrix4x4<T>& aMatrix)
	{
		for (unsigned int rows = 0; rows < 4; rows++)
		{
			for (unsigned int columns = 0; columns < 4; columns++)
			{
				myMatrix[rows][columns] = aMatrix(rows + 1, columns + 1);
			}
		}
		return *this;
	}

	template<class T>
	inline bool Matrix4x4<T>::operator==(const Matrix4x4<T>& aMatrix) const
	{
		for (unsigned int rows = 0; rows < 4; rows++)
		{
			for (unsigned int columns = 0; columns < 4; columns++)
			{
				if (myMatrix[rows][columns] != aMatrix(rows + 1, columns + 1))
				{
					return false;
				}
			}
		}
		return  true;
	}

	template<class T>
	inline Matrix4x4<T> Matrix4x4<T>::CreateRotationAroundX(T aAngleInRadians)
	{
		Matrix4x4<T> temp;
		temp(1, 1) = 1;
		temp(1, 2) = 0;
		temp(1, 3) = 0;
		temp(1, 4) = 0;

		temp(2, 1) = 0;
		temp(2, 2) = static_cast<T>(cos(aAngleInRadians));
		temp(2, 3) = static_cast<T>(sin(aAngleInRadians));
		temp(2, 4) = 0;

		temp(3, 1) = 0;
		temp(3, 2) = static_cast<T>(-sin(aAngleInRadians));
		temp(3, 3) = static_cast<T>(cos(aAngleInRadians));
		temp(3, 4) = 0;

		temp(4, 1) = 0;
		temp(4, 2) = 0;
		temp(4, 3) = 0;
		temp(4, 4) = 1;

		return temp;
	}

	template<class T>
	inline Matrix4x4<T> Matrix4x4<T>::CreateRotationAroundY(T aAngleInRadians)
	{
		Matrix4x4<T> temp;
		temp(1, 1) = static_cast<T>(cos(aAngleInRadians));
		temp(1, 2) = 0;
		temp(1, 3) = static_cast<T>(-sin(aAngleInRadians));
		temp(1, 4) = 0;

		temp(2, 1) = 0;
		temp(2, 2) = 1;
		temp(2, 3) = 0;
		temp(2, 4) = 0;

		temp(3, 1) = static_cast<T>(sin(aAngleInRadians));
		temp(3, 2) = 0;
		temp(3, 3) = static_cast<T>(cos(aAngleInRadians));
		temp(3, 4) = 0;

		temp(4, 1) = 0;
		temp(4, 2) = 0;
		temp(4, 3) = 0;
		temp(4, 4) = 1;

		return temp;
	}

	template<class T>
	inline Matrix4x4<T> Matrix4x4<T>::CreateRotationAroundZ(T aAngleInRadians)
	{
		Matrix4x4<T> temp;
		temp(1, 1) = static_cast<T>(cos(aAngleInRadians));
		temp(1, 2) = static_cast<T>(sin(aAngleInRadians));
		temp(1, 3) = 0;
		temp(1, 4) = 0;

		temp(2, 1) = static_cast<T>(-sin(aAngleInRadians));
		temp(2, 2) = static_cast<T>(cos(aAngleInRadians));
		temp(2, 3) = 0;
		temp(2, 4) = 0;

		temp(3, 1) = 0;
		temp(3, 2) = 0;
		temp(3, 3) = 1;
		temp(3, 4) = 0;

		temp(4, 1) = 0;
		temp(4, 2) = 0;
		temp(4, 3) = 0;
		temp(4, 4) = 1;

		return temp;
	}

	template<class T>
	inline Matrix4x4<T> Matrix4x4<T>::Transpose(const Matrix4x4<T>& aMatrixToTranspose)
	{
		Matrix4x4<T> temp;
		temp(1, 1) = aMatrixToTranspose(1, 1);
		temp(1, 2) = aMatrixToTranspose(2, 1);
		temp(1, 3) = aMatrixToTranspose(3, 1);
		temp(1, 4) = aMatrixToTranspose(4, 1);

		temp(2, 1) = aMatrixToTranspose(1, 2);
		temp(2, 2) = aMatrixToTranspose(2, 2);
		temp(2, 3) = aMatrixToTranspose(3, 2);
		temp(2, 4) = aMatrixToTranspose(4, 2);

		temp(3, 1) = aMatrixToTranspose(1, 3);
		temp(3, 2) = aMatrixToTranspose(2, 3);
		temp(3, 3) = aMatrixToTranspose(3, 3);
		temp(3, 4) = aMatrixToTranspose(4, 3);

		temp(4, 1) = aMatrixToTranspose(1, 4);
		temp(4, 2) = aMatrixToTranspose(2, 4);
		temp(4, 3) = aMatrixToTranspose(3, 4);
		temp(4, 4) = aMatrixToTranspose(4, 4);
		return temp;
	}
}